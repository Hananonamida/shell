#!/bin/bash
curl -X GET "http://127.0.0.1:12391/admin/status" -H  "accept: application/json"
echo
curl -X GET "http://127.0.0.1:12391/admin/mintingaccounts" -H  "accept: application/json"
echo