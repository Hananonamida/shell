#!/bin/bash
pid=$(cat run.pid) && [ -n "$pid" ] && kill -9 "$pid" && echo "Process with PID $pid has been terminated." || echo "No PID found in run.pid file." && rm -f run.pid
